"""Tibia Character Verification: FastAPI, SQLite and TibiaData v4.

No Tibia credentials are ever requested. Character comment codes demonstrate
control of the public character profile at the time of verification.
"""
from __future__ import annotations

import asyncio
import csv
import hashlib
import hmac
import io
import json
import os
import re
import secrets
import sqlite3
import time
from datetime import datetime, timezone, timedelta
from pathlib import Path
from urllib.parse import quote

import httpx
from fastapi import FastAPI, File, HTTPException, Request, UploadFile
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse, StreamingResponse, Response
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from PIL import Image, ImageOps, UnidentifiedImageError
from pydantic import BaseModel, Field
from starlette.middleware.sessions import SessionMiddleware

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("TIBIA_DATA_DIR", str(BASE_DIR / "data")))
DATA_DIR.mkdir(parents=True, exist_ok=True)
UPLOAD_DIR = DATA_DIR / "uploads"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = DATA_DIR / "tibia_verification.sqlite3"
API_ROOT = os.environ.get("TIBIADATA_URL", "https://api.tibiadata.com/v5").rstrip("/")
ADMIN_USERNAME = os.environ.get("ADMIN_USERNAME", "admin")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "hej123")
SESSION_HTTPS_ONLY = os.environ.get("COOKIE_SECURE", "0") == "1"
PRODUCTION = os.environ.get("PRODUCTION", "0") == "1"
if PRODUCTION:
    if ADMIN_PASSWORD == "hej123" or len(ADMIN_PASSWORD) < 16:
        raise RuntimeError("Set a unique ADMIN_PASSWORD with at least 16 characters for production")
    if len(os.environ.get("SESSION_SECRET", "")) < 32:
        raise RuntimeError("Set SESSION_SECRET (32+ characters) for production")
    if not SESSION_HTTPS_ONLY:
        raise RuntimeError("Set COOKIE_SECURE=1 for HTTPS production use")
    if not os.environ.get("TIBIA_DATA_DIR"):
        raise RuntimeError("Set TIBIA_DATA_DIR to a persistent disk mount")
MAX_IMAGE_BYTES = 6 * 1024 * 1024
Image.MAX_IMAGE_PIXELS = 14_000_000
NAME_PATTERN = re.compile(r"^[A-Za-z][A-Za-z '\-]{1,29}$")
CODE_PATTERN = re.compile(r"(?<![A-Z0-9])TCV-[A-Z0-9]{4}-[A-Z0-9]{4}(?![A-Z0-9])", re.IGNORECASE)
ROLES = ("main", "green", "yellow")


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def get_secret() -> str:
    secret = os.environ.get("SESSION_SECRET", "")
    if secret:
        return secret
    location = DATA_DIR / ".session_secret"
    if not location.exists():
        # O_EXCL prevents another worker from overwriting the persistent key.
        try:
            fd = os.open(location, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
            with os.fdopen(fd, "w") as f:
                f.write(secrets.token_hex(48))
        except FileExistsError:
            pass
    return location.read_text().strip()


app = FastAPI(title="Tibia Character Verification", docs_url=None, redoc_url=None)
app.add_middleware(SessionMiddleware, secret_key=get_secret(), same_site="lax", https_only=SESSION_HTTPS_ONLY, max_age=12 * 3600)
@app.middleware("http")
async def browser_security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    response.headers["Content-Security-Policy"] = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'"
    if PRODUCTION:
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    if request.url.path.startswith("/api/admin") or request.url.path.startswith("/admin") or request.url.path.startswith("/api/submissions"):
        response.headers["Cache-Control"] = "private, no-store"
    return response

app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")
templates = Jinja2Templates(directory=BASE_DIR / "templates")


def connect():
    conn = sqlite3.connect(DB_PATH, timeout=15)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA busy_timeout = 15000")
    return conn


def init_db():
    with connect() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS submissions (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          token TEXT NOT NULL UNIQUE,
          main_name TEXT NOT NULL,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'pending',
          admin_note TEXT NOT NULL DEFAULT '',
          reviewed_at TEXT,
          last_verify_at TEXT
        );
        CREATE TABLE IF NOT EXISTS characters (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          submission_id INTEGER NOT NULL REFERENCES submissions(id) ON DELETE CASCADE,
          role TEXT NOT NULL CHECK(role IN ('main','green','yellow')),
          name TEXT NOT NULL,
          code TEXT NOT NULL,
          code_expires_at TEXT NOT NULL,
          verification_status TEXT NOT NULL DEFAULT 'pending',
          checked_at TEXT,
          error TEXT NOT NULL DEFAULT '',
          world_match INTEGER NOT NULL DEFAULT 0,
          screenshot_file TEXT,
          screenshot_uploaded_at TEXT,
          profile_json TEXT NOT NULL DEFAULT '{}',
          UNIQUE(submission_id, role)
        );
        CREATE INDEX IF NOT EXISTS idx_submissions_main ON submissions(main_name);
        CREATE INDEX IF NOT EXISTS idx_characters_submission ON characters(submission_id);
        """)


init_db()


class SubmissionInput(BaseModel):
    main: str = Field(min_length=2, max_length=30)
    green: str = Field(min_length=2, max_length=30)
    yellow: str = Field(min_length=2, max_length=30)
    consent: bool = False


class LoginInput(BaseModel):
    username: str
    password: str


class ReviewInput(BaseModel):
    decision: str
    note: str = Field(default="", max_length=2000)


def normalize_name(name: str) -> str:
    return " ".join(name.split()).strip()


def validate_name(name: str) -> str:
    value = normalize_name(name)
    if not NAME_PATTERN.fullmatch(value):
        raise HTTPException(422, "Use a valid Tibia character name (2–30 letters, spaces, apostrophe or hyphen).")
    return value


def make_code() -> str:
    # 40 bits of random challenge entropy; independent per character.
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    return "TCV-" + "".join(secrets.choice(alphabet) for _ in range(4)) + "-" + "".join(secrets.choice(alphabet) for _ in range(4))


def get_submission(token: str):
    with connect() as db:
        item = db.execute("SELECT * FROM submissions WHERE token = ?", (token,)).fetchone()
        if not item:
            raise HTTPException(404, "Submission not found")
        chars = db.execute("SELECT * FROM characters WHERE submission_id=? ORDER BY CASE role WHEN 'main' THEN 1 WHEN 'green' THEN 2 ELSE 3 END", (item["id"],)).fetchall()
        return item, chars


def character_public(c, admin=False):
    try:
        profile = json.loads(c["profile_json"] or "{}")
    except json.JSONDecodeError:
        profile = {}
    out = {
        "role": c["role"], "name": c["name"], "code": c["code"],
        "code_expires_at": c["code_expires_at"],
        "verification_status": c["verification_status"],
        "checked_at": c["checked_at"], "error": c["error"],
        "world_match": bool(c["world_match"]),
        "has_screenshot": bool(c["screenshot_file"]),
        "screenshot_uploaded_at": c["screenshot_uploaded_at"],
        "profile": profile,
    }
    if admin:
        out["screenshot_url"] = f"/admin/screenshots/{c['id']}" if c["screenshot_file"] else None
    return out


def public_submission(item, chars, admin=False):
    result = {
        "id": item["id"] if admin else None,
        "main_name": item["main_name"],
        "status": item["status"], "created_at": item["created_at"],
        "updated_at": item["updated_at"],
        "last_verify_at": item["last_verify_at"],
        "characters": [character_public(c, admin) for c in chars],
        "ready_for_review": all(c["verification_status"] == "verified" for c in chars)
            and all(bool(c["screenshot_file"]) for c in chars if c["role"] != "main"),
    }
    if admin:
        result["admin_note"] = item["admin_note"]
        result["reviewed_at"] = item["reviewed_at"]
        result["account_links"] = infer_public_account_links(result["characters"])
    return result


def infer_public_account_links(chars):
    """Positive account association only when a public other_characters list shows it."""
    lines = []
    for i, left in enumerate(chars):
        for right in chars[i + 1:]:
            left_list = {str(x.get("name", "")).casefold() for x in left["profile"].get("other_characters", []) if isinstance(x, dict)}
            right_list = {str(x.get("name", "")).casefold() for x in right["profile"].get("other_characters", []) if isinstance(x, dict)}
            visible = right["name"].casefold() in left_list or left["name"].casefold() in right_list
            lines.append({"a": left["role"], "b": right["role"], "publicly_linked": visible})
    return lines


@app.get("/", response_class=HTMLResponse)
def index(request: Request):
    return templates.TemplateResponse(request, "index.html")


@app.get("/privacy", response_class=HTMLResponse)
def privacy_notice(request: Request):
    return templates.TemplateResponse(request, "privacy.html")


@app.get("/verify/{token}", response_class=HTMLResponse)
def verification_page(request: Request, token: str):
    get_submission(token)
    return templates.TemplateResponse(request, "verify.html", {"token": token})


@app.post("/api/submissions", status_code=201)
def create_submission(payload: SubmissionInput):
    if not payload.consent:
        raise HTTPException(422, "You must agree to the privacy notice before submitting screenshots or character information.")
    names = {role: validate_name(getattr(payload, role)) for role in ROLES}
    if len({n.casefold() for n in names.values()}) != 3:
        raise HTTPException(422, "All three character names must be different.")
    now = utcnow()
    token = secrets.token_urlsafe(28)
    exp = (datetime.now(timezone.utc) + timedelta(days=7)).isoformat(timespec="seconds")
    with connect() as db:
        cur = db.execute("INSERT INTO submissions(token,main_name,created_at,updated_at) VALUES (?,?,?,?)", (token, names["main"], now, now))
        for role in ROLES:
            db.execute("INSERT INTO characters(submission_id,role,name,code,code_expires_at) VALUES (?,?,?,?,?)", (cur.lastrowid, role, names[role], make_code(), exp))
    return {"token": token, "url": f"/verify/{token}"}


@app.get("/api/submissions/{token}")
def submission_detail(token: str):
    return public_submission(*get_submission(token))


def classify_world(world: dict | None):
    if not world or world.get("battleye_protected") is not True:
        return "unknown"
    date = str(world.get("battleye_date") or "").strip().lower()
    if date in {"release", "since release", "from the beginning"}:
        return "green"
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", date):
        return "yellow"
    return "unknown"


async def fetch_world_map(client: httpx.AsyncClient):
    res = await client.get(f"{API_ROOT}/worlds")
    res.raise_for_status()
    data = res.json().get("worlds") or {}
    worlds = (data.get("regular_worlds") or []) + (data.get("tournament_worlds") or [])
    return {w["name"].casefold(): w for w in worlds if isinstance(w, dict) and w.get("name")}


async def fetch_character(client: httpx.AsyncClient, name: str):
    url = f"{API_ROOT}/character/{quote(name, safe='')}"
    res = await client.get(url)
    if res.status_code == 404:
        return None
    res.raise_for_status()
    data = res.json()
    status = ((data.get("information") or {}).get("status") or {})
    if status.get("http_code") == 404:
        return None
    root = data.get("characters") or {}
    char = root.get("character") or data.get("character")
    if not isinstance(char, dict) or not char.get("name"):
        return None
    guild = char.get("guild") or char.get("guild_membership") or {}
    if isinstance(guild, str):
        guild = {"name": guild}
    linked = root.get("other_characters") or char.get("other_characters") or []
    linked = linked if isinstance(linked, list) else []
    acct = char.get("account_status")
    if not acct and isinstance(char.get("is_premium"), bool):
        acct = "Premium Account" if char["is_premium"] else "Free Account"
    return {
        "name": str(char.get("name", "")),
        "world": str(char.get("world", "")),
        "level": char.get("level"), "vocation": char.get("vocation"),
        "last_login": char.get("last_login"),
        "account_status": acct,
        "guild": guild.get("name") or None,
        "guild_rank": guild.get("rank") or None,
        "comment": str(char.get("comment") or ""),
        "other_characters": [{"name": x.get("name"), "world": x.get("world")}
                             for x in linked if isinstance(x, dict) and x.get("name")][:100],
        "api_checked_at": utcnow(),
    }


def evaluate_character(c, profile, worlds):
    """Compute a result; 'unknown' never counts as a verified green/yellow world."""
    if profile is None:
        return "not_found", False, "Character was not found on TibiaData.", {}
    if profile["name"].casefold() != c["name"].casefold():
        return "mismatch", False, "The retrieved character name does not match.", {}
    world = worlds.get(profile["world"].casefold())
    protection = classify_world(world)
    profile["battleye"] = protection
    profile["world_protection_date"] = world.get("battleye_date") if world else None
    matches = profile["world"].casefold() == "premia" if c["role"] == "main" else protection == c["role"]
    if not matches:
        if c["role"] == "main":
            return "mismatch", False, "Main character must be on Premia.", profile
        if protection == "unknown":
            return "unavailable", False, "Could not confirm the world's BattlEye protection category.", profile
        return "mismatch", False, f"Expected a {c['role']} BattlEye world, but this is a {protection} world.", profile
    try:
        expires = datetime.fromisoformat(c["code_expires_at"])
        if datetime.now(timezone.utc) > expires:
            return "expired", True, "The seven-day verification code has expired. Contact the administrator to restart.", profile
    except ValueError:
        pass
    comment = profile.pop("comment", "")
    # Match the exact challenge, not fragments of another longer token.
    codes = {m.group(0).upper() for m in CODE_PATTERN.finditer(comment)}
    if c["code"].upper() not in codes:
        return "pending", True, "Verification code not found in the character's public comment yet.", profile
    return "verified", True, "Ownership code confirmed in the public character comment.", profile


def update_submission_status(db, submission_id: int):
    chars = db.execute("SELECT * FROM characters WHERE submission_id=?", (submission_id,)).fetchall()
    ready = len(chars) == 3 and all(c["verification_status"] == "verified" for c in chars) and all(c["screenshot_file"] for c in chars if c["role"] != "main")
    row = db.execute("SELECT status FROM submissions WHERE id=?", (submission_id,)).fetchone()
    if row and row["status"] not in {"approved", "rejected"}:
        new_status = "ready" if ready else "pending"
        db.execute("UPDATE submissions SET status=?,updated_at=? WHERE id=?", (new_status, utcnow(), submission_id))
    elif row and row["status"] == "approved" and not ready:
        # Rechecks can uncover discrepancies: never silently keep a now-failing approval.
        db.execute("UPDATE submissions SET status='pending',updated_at=? WHERE id=?", (utcnow(), submission_id))


@app.post("/api/submissions/{token}/check")
async def check_codes(token: str):
    item, chars = get_submission(token)
    if item["status"] in {"approved", "rejected"}:
        raise HTTPException(409, "This submission has been reviewed and is locked. Contact the administrator for changes.")
    if item["last_verify_at"]:
        previous = datetime.fromisoformat(item["last_verify_at"])
        if datetime.now(timezone.utc) - previous < timedelta(seconds=20):
            raise HTTPException(429, "Please wait 20 seconds before checking again.")
    # Claim the check window before making external requests to limit parallel abuse.
    with connect() as db:
        db.execute("UPDATE submissions SET last_verify_at=? WHERE id=?", (utcnow(), item["id"]))
    try:
        async with httpx.AsyncClient(timeout=17, follow_redirects=False, headers={"User-Agent": "TibiaVerification/1.0 (public-character-verifier)"}) as client:
            worlds, *profiles = await asyncio.gather(fetch_world_map(client), *[fetch_character(client, c["name"]) for c in chars], return_exceptions=True)
        if isinstance(worlds, Exception):
            raise ValueError("World lookup is unavailable. Try again later.")
    except Exception as exc:
        raise HTTPException(503, "TibiaData is temporarily unavailable. Your submission is saved; please retry.") from exc

    now = utcnow()
    with connect() as db:
        for c, profile in zip(chars, profiles):
            if isinstance(profile, Exception):
                # API outages do not count as invalid character ownership.
                db.execute("UPDATE characters SET error=?,checked_at=? WHERE id=?", ("Could not reach the character lookup service; retry later.", now, c["id"]))
                continue
            status, world_match, message, filtered = evaluate_character(c, profile, worlds)
            db.execute("""UPDATE characters SET verification_status=?,world_match=?,error=?,checked_at=?,profile_json=? WHERE id=?""",
                       (status, int(world_match), message, now, json.dumps(filtered), c["id"]))
        update_submission_status(db, item["id"])
    return public_submission(*get_submission(token))


@app.post("/api/submissions/{token}/screenshot/{role}")
async def screenshot_upload(token: str, role: str, file: UploadFile = File(...)):
    if role not in {"green", "yellow"}:
        raise HTTPException(400, "Screenshots are required for the green and yellow characters only.")
    item, chars = get_submission(token)
    if item["status"] in {"approved", "rejected"}:
        raise HTTPException(409, "This submission has already been reviewed and is locked.")
    contents = await file.read(MAX_IMAGE_BYTES + 1)
    if not contents or len(contents) > MAX_IMAGE_BYTES:
        raise HTTPException(413, "Image must be under 6 MB.")
    try:
        with Image.open(io.BytesIO(contents)) as img:
            if img.format not in {"PNG", "JPEG", "WEBP"}:
                raise ValueError("Unsupported image format")
            img.verify()
        with Image.open(io.BytesIO(contents)) as img:
            if img.width * img.height > 14_000_000:
                raise ValueError("Image dimensions too large")
            clean = ImageOps.exif_transpose(img).convert("RGB")
            if clean.width > 2400 or clean.height > 2400:
                clean.thumbnail((2400, 2400))
            image_bytes = io.BytesIO()
            clean.save(image_bytes, "WEBP", quality=85, method=5)
    except (UnidentifiedImageError, ValueError, Image.DecompressionBombError, OSError) as exc:
        raise HTTPException(415, "Upload a valid PNG, JPEG or WebP screenshot.") from exc
    filename = secrets.token_hex(24) + ".webp"
    (UPLOAD_DIR / filename).write_bytes(image_bytes.getvalue())
    with connect() as db:
        previous = db.execute("SELECT screenshot_file FROM characters WHERE submission_id=? AND role=?", (item["id"], role)).fetchone()
        old_file = previous["screenshot_file"] if previous else None
        db.execute("UPDATE characters SET screenshot_file=?,screenshot_uploaded_at=? WHERE submission_id=? AND role=?", (filename, utcnow(), item["id"], role))
        update_submission_status(db, item["id"])
    if old_file:
        (UPLOAD_DIR / old_file).unlink(missing_ok=True)
    return public_submission(*get_submission(token))


@app.get("/admin", response_class=HTMLResponse)
def admin_home(request: Request):
    if not request.session.get("admin"):
        return RedirectResponse("/admin/login", status_code=303)
    csrf = request.session.get("csrf") or secrets.token_urlsafe(32)
    request.session["csrf"] = csrf
    return templates.TemplateResponse(request, "admin.html", {"csrf": csrf})


@app.get("/admin/login", response_class=HTMLResponse)
def admin_login(request: Request):
    if request.session.get("admin"):
        return RedirectResponse("/admin", status_code=303)
    return templates.TemplateResponse(request, "login.html")


# Small in-memory throttle for a local/single-instance deployment. Put a real
# reverse-proxy rate limiter in front of a public multi-worker deployment.
LOGIN_FAILURES = {}


@app.post("/api/admin/login")
def login(payload: LoginInput, request: Request):
    address = request.client.host if request.client else "unknown"
    attempts = [x for x in LOGIN_FAILURES.get(address, []) if time.monotonic() - x < 900]
    if len(attempts) >= 8:
        raise HTTPException(429, "Too many attempts. Try again in 15 minutes.")
    valid_user = hmac.compare_digest(payload.username.encode(), ADMIN_USERNAME.encode())
    valid_pw = hmac.compare_digest(payload.password.encode(), ADMIN_PASSWORD.encode())
    if not (valid_user and valid_pw):
        attempts.append(time.monotonic())
        LOGIN_FAILURES[address] = attempts
        raise HTTPException(401, "Incorrect username or password")
    LOGIN_FAILURES.pop(address, None)
    request.session.clear()
    request.session["admin"] = True
    request.session["csrf"] = secrets.token_urlsafe(32)
    return {"ok": True}


def require_admin(request: Request):
    if not request.session.get("admin"):
        raise HTTPException(401, "Admin login required")


def require_csrf(request: Request):
    require_admin(request)
    if not hmac.compare_digest(request.headers.get("X-CSRF-Token", ""), request.session.get("csrf", "")):
        raise HTTPException(403, "Invalid security token")


@app.post("/api/admin/logout")
def logout(request: Request):
    require_csrf(request)
    request.session.clear()
    return {"ok": True}


@app.get("/api/admin/submissions")
def admin_list(request: Request, search: str = "", status: str = ""):
    require_admin(request)
    sql = "SELECT * FROM submissions WHERE 1=1"
    args = []
    if search.strip():
        sql += " AND (main_name LIKE ? OR EXISTS (SELECT 1 FROM characters c WHERE c.submission_id=submissions.id AND c.name LIKE ?))"
        args.extend([f"%{search.strip()}%"] * 2)
    if status in {"pending", "ready", "approved", "rejected"}:
        sql += " AND status=?"
        args.append(status)
    sql += " ORDER BY created_at DESC LIMIT 500"
    with connect() as db:
        entries = db.execute(sql, args).fetchall()
        output = []
        for entry in entries:
            chars = db.execute("SELECT * FROM characters WHERE submission_id=? ORDER BY CASE role WHEN 'main' THEN 1 WHEN 'green' THEN 2 ELSE 3 END", (entry["id"],)).fetchall()
            output.append(public_submission(entry, chars, admin=True))
        totals = dict(db.execute("SELECT status, COUNT(*) AS n FROM submissions GROUP BY status").fetchall())
    return {"items": output, "totals": totals, "total": sum(totals.values())}


@app.get("/api/admin/submissions/{sid}")
def admin_detail(sid: int, request: Request):
    require_admin(request)
    with connect() as db:
        entry = db.execute("SELECT * FROM submissions WHERE id=?", (sid,)).fetchone()
        if not entry:
            raise HTTPException(404)
        chars = db.execute("SELECT * FROM characters WHERE submission_id=? ORDER BY CASE role WHEN 'main' THEN 1 WHEN 'green' THEN 2 ELSE 3 END", (sid,)).fetchall()
    return public_submission(entry, chars, admin=True)


@app.post("/api/admin/submissions/{sid}/review")
def admin_review(sid: int, payload: ReviewInput, request: Request):
    require_csrf(request)
    if payload.decision not in {"approved", "rejected", "pending"}:
        raise HTTPException(422, "Unknown review decision")
    with connect() as db:
        item = db.execute("SELECT * FROM submissions WHERE id=?", (sid,)).fetchone()
        if not item:
            raise HTTPException(404)
        chars = db.execute("SELECT * FROM characters WHERE submission_id=?", (sid,)).fetchall()
        if payload.decision == "approved":
            if not (len(chars) == 3 and all(c["verification_status"] == "verified" for c in chars)
                    and all(c["screenshot_file"] for c in chars if c["role"] != "main")):
                raise HTTPException(409, "All codes, worlds, and two screenshots must be verified before approval.")
        db.execute("UPDATE submissions SET status=?,admin_note=?,reviewed_at=?,updated_at=? WHERE id=?",
                   (payload.decision, payload.note.strip(), utcnow(), utcnow(), sid))
    return {"ok": True}


@app.delete("/api/admin/submissions/{sid}")
def admin_delete(sid: int, request: Request):
    """Permanently remove a submission and uploaded screenshots, including private evidence."""
    require_csrf(request)
    with connect() as db:
        row = db.execute("SELECT id FROM submissions WHERE id=?", (sid,)).fetchone()
        if not row:
            raise HTTPException(404, "Submission not found")
        files = [r[0] for r in db.execute("SELECT screenshot_file FROM characters WHERE submission_id=? AND screenshot_file IS NOT NULL", (sid,)).fetchall()]
        db.execute("DELETE FROM submissions WHERE id=?", (sid,))
    for filename in files:
        (UPLOAD_DIR / filename).unlink(missing_ok=True)
    return {"ok": True, "deleted_id": sid}


@app.get("/admin/screenshots/{character_id}")
def private_screenshot(character_id: int, request: Request):
    require_admin(request)
    with connect() as db:
        row = db.execute("SELECT screenshot_file FROM characters WHERE id=?", (character_id,)).fetchone()
    if not row or not row["screenshot_file"]:
        raise HTTPException(404)
    file = UPLOAD_DIR / row["screenshot_file"]
    if not file.is_file():
        raise HTTPException(404)
    return Response(content=file.read_bytes(), media_type="image/webp", headers={"Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff"})


@app.get("/api/admin/export.csv")
def admin_export(request: Request):
    require_admin(request)
    with connect() as db:
        items = db.execute("""SELECT s.*, c.role, c.name, c.verification_status, c.screenshot_file, c.profile_json
                              FROM submissions s JOIN characters c ON c.submission_id=s.id
                              ORDER BY s.created_at DESC,s.id,c.id""").fetchall()
    buffer = io.StringIO()
    writer = csv.writer(buffer)
    writer.writerow(["Submission ID", "Premia main", "Overall status", "Character role", "Character name", "Verification", "Screenshot uploaded", "World", "BattlEye", "Level", "Vocation", "Premium status", "Guild", "Last login", "Created", "Admin note"])
    for row in items:
        p = json.loads(row["profile_json"] or "{}")
        writer.writerow([row["id"], row["main_name"], row["status"], row["role"], row["name"], row["verification_status"], "Yes" if row["screenshot_file"] else "No", p.get("world", ""), p.get("battleye", ""), p.get("level", ""), p.get("vocation", ""), p.get("account_status", ""), p.get("guild", ""), p.get("last_login", ""), row["created_at"], row["admin_note"]])
    return StreamingResponse(iter([buffer.getvalue().encode("utf-8-sig")]), media_type="text/csv", headers={"Content-Disposition": 'attachment; filename="tibia-verification-report.csv"', "Cache-Control": "no-store"})


@app.get("/health")
def health():
    return {"status": "ok"}
