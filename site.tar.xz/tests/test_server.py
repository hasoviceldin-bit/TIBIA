import io
import json
import pytest
from fastapi.testclient import TestClient
from PIL import Image
import server

@pytest.fixture
def client(tmp_path,monkeypatch):
    monkeypatch.setattr(server,'DB_PATH',tmp_path/'test.sqlite3')
    monkeypatch.setattr(server,'UPLOAD_DIR',tmp_path/'uploads')
    server.UPLOAD_DIR.mkdir()
    server.init_db()
    return TestClient(server.app)


def test_world_classification():
    assert server.classify_world({'battleye_protected':True,'battleye_date':'release'}) == 'green'
    assert server.classify_world({'battleye_protected':True,'battleye_date':'2017-09-05'}) == 'yellow'
    assert server.classify_world({'battleye_protected':False,'battleye_date':'release'}) == 'unknown'
    assert server.classify_world({'battleye_protected':True,'battleye_date':None}) == 'unknown'


def test_name_checks(client):
    r=client.post('/api/submissions',json={'main':'One Name','green':'One Name','yellow':'Third Name','consent':True})
    assert r.status_code==422
    r=client.post('/api/submissions',json={'main':'One Name','green':'<script>','yellow':'Third Name','consent':True})
    assert r.status_code==422


def test_full_verification_and_admin_access(client,monkeypatch):
    response=client.post('/api/submissions',json={'main':'Test Main','green':'Test Green','yellow':'Test Yellow','consent':True})
    assert response.status_code==201
    token=response.json()['token']
    chars=client.get(f'/api/submissions/{token}').json()['characters']
    codes={c['name']:c['code'] for c in chars}
    async def fake_worlds(client):
        return {'premia':{'battleye_protected':True,'battleye_date':'2017-09-05'},
                'greentown':{'battleye_protected':True,'battleye_date':'release'},
                'yellowtown':{'battleye_protected':True,'battleye_date':'2018-09-05'}}
    async def fake_character(client,name):
        return {'name':name,'world':{'Test Main':'Premia','Test Green':'Greentown','Test Yellow':'Yellowtown'}[name],
                'level':350,'vocation':'Elite Knight','last_login':'2026-11-20T01:00:00Z','account_status':'Premium Account',
                'guild':'Test Guild','guild_rank':'Member','comment':'hey '+codes[name]+' goodbye',
                'other_characters':[{'name':x,'world':'Premia'} for x in codes]}
    monkeypatch.setattr(server,'fetch_world_map',fake_worlds)
    monkeypatch.setattr(server,'fetch_character',fake_character)
    r=client.post(f'/api/submissions/{token}/check')
    assert r.status_code==200,r.text
    assert all(c['verification_status']=='verified' for c in r.json()['characters'])
    assert r.json()['status']=='pending'
    assert client.post(f'/api/submissions/{token}/check').status_code == 429
    pic=Image.new('RGB',(25,25),(255,255,0))
    b=io.BytesIO();pic.save(b,format='PNG')
    content=b.getvalue()
    assert client.post(f'/api/submissions/{token}/screenshot/green',files={'file':('test.png',content,'image/png')}).status_code==200
    r=client.post(f'/api/submissions/{token}/screenshot/yellow',files={'file':('test.png',content,'image/png')})
    assert r.status_code==200
    assert r.json()['ready_for_review'] is True
    assert r.json()['status']=='ready'
    assert client.get('/api/admin/submissions').status_code==401
    assert client.get('/admin/screenshots/1').status_code==401
    assert client.post('/api/admin/login',json={'username':'admin','password':'bad'}).status_code==401
    assert client.post('/api/admin/login',json={'username':'admin','password':'hej123'}).status_code==200
    admin_page=client.get('/admin');assert admin_page.status_code==200
    import re
    csrf=re.search(r'content="([^"]+)"',admin_page.text.split('name="csrf-token"')[1]).group(1)
    report=client.get('/api/admin/submissions').json()
    assert report['total']==1
    sid=report['items'][0]['id']
    assert len(report['items'][0]['account_links']) == 3
    assert all(x['publicly_linked'] for x in report['items'][0]['account_links'])
    assert client.post(f'/api/admin/submissions/{sid}/review',json={'decision':'approved'},headers={'X-CSRF-Token':'bad'}).status_code==403
    assert client.post(f'/api/admin/submissions/{sid}/review',json={'decision':'approved'},headers={'X-CSRF-Token':csrf}).status_code==200
    assert client.get('/api/admin/submissions').json()['items'][0]['status']=='approved'
    assert client.post(f'/api/submissions/{token}/check').status_code == 409
    assert client.post(f'/api/submissions/{token}/screenshot/green',files={'file':('test.png',content,'image/png')}).status_code == 409
    detail=client.get('/api/admin/submissions/'+str(sid)).json()
    screenshot=next(c['screenshot_url'] for c in detail['characters'] if c['role']=='green')
    assert client.get(screenshot).status_code==200
    assert client.get('/api/admin/export.csv').status_code==200


def test_cannot_approve_incomplete(client):
    token=client.post('/api/submissions',json={'main':'One Main','green':'Other Green','yellow':'Other Yellow','consent':True}).json()['token']
    assert client.post('/api/admin/login',json={'username':'admin','password':'hej123'}).status_code == 200
    page=client.get('/admin').text
    import re
    csrf=re.search(r'content="([^"]+)"',page.split('name="csrf-token"')[1]).group(1)
    sid=client.get('/api/admin/submissions').json()['items'][0]['id']
    result=client.post(f'/api/admin/submissions/{sid}/review',json={'decision':'approved'},headers={'X-CSRF-Token':csrf})
    assert result.status_code==409
    assert client.get('/api/admin/submissions').json()['items'][0]['status']=='pending'


def test_privacy_and_deletion(client):
    bad=client.post('/api/submissions',json={'main':'Test Main','green':'Test Green','yellow':'Test Yellow'})
    assert bad.status_code == 422
    assert client.get('/privacy').status_code == 200
    token=client.post('/api/submissions',json={'main':'Test Main','green':'Test Green','yellow':'Test Yellow','consent':True}).json()['token']
    assert client.post('/api/admin/login',json={'username':'admin','password':'hej123'}).status_code == 200
    import re
    page=client.get('/admin').text
    csrf=re.search(r'content="([^"]+)"',page.split('name="csrf-token"')[1]).group(1)
    sid=client.get('/api/admin/submissions').json()['items'][0]['id']
    assert client.delete(f'/api/admin/submissions/{sid}').status_code == 403
    assert client.delete(f'/api/admin/submissions/{sid}',headers={'X-CSRF-Token':csrf}).status_code == 200
    assert client.get(f'/api/submissions/{token}').status_code == 404
