'use strict';
const $ = (q) => document.querySelector(q);
const safe = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const labels = {main:'PREMIA MAIN',green:'GREEN BATTLEYE',yellow:'YELLOW BATTLEYE'};
const icons = {main:'✦',green:'●',yellow:'●'};
const pretty = {pending:'Pending',verified:'Verified',mismatch:'World mismatch',not_found:'Not found',unavailable:'Lookup unavailable',expired:'Code expired',approved:'Approved',ready:'Ready for review',rejected:'Rejected'};
async function api(url, options={}) {
  let response;
  try { response = await fetch(url, {credentials:'same-origin', ...options}); }
  catch { throw new Error('Unable to connect to the server. Check your connection and retry.'); }
  const content = await response.json().catch(()=>({}));
  if (!response.ok) {
    const msg = typeof content.detail === 'string' ? content.detail : `Request failed (${response.status})`;
    throw new Error(msg);
  }
  return content;
}
function error(el,text){if(!el)return;el.textContent=text;el.hidden=!text;}
function setBusy(btn,busy,caption){btn.disabled=busy;if(caption){if(busy){btn.dataset.original=btn.innerHTML;btn.innerHTML=caption;}else if(btn.dataset.original){btn.innerHTML=btn.dataset.original;}}}
function saveLink(token){try{localStorage.setItem('last-tibia-verify',token);}catch{}}
function home(){const form=$('#register-form');if(!form)return;
  form.addEventListener('submit',async e=>{e.preventDefault();const btn=$('#submit-button');error($('#form-error'),'');setBusy(btn,true,'Creating your challenges…');
    try {const names=Object.fromEntries(['main','green','yellow'].map(k=>[k,$('#'+k).value.trim()]));const data=await api('/api/submissions',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...names,consent:$('#consent').checked})});saveLink(data.token);location.assign(data.url);}
    catch(ex){error($('#form-error'),ex.message);setBusy(btn,false);}
  });
}
function login(){const form=$('#login-form');if(!form)return;
  form.addEventListener('submit',async e=>{e.preventDefault();const btn=$('#login-btn');setBusy(btn,true,'Signing in…');error($('#login-error'),'');try{await api('/api/admin/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:$('#username').value,password:$('#password').value})});location.assign('/admin');}catch(ex){error($('#login-error'),ex.message);setBusy(btn,false);}});
}
function publicUrl(name){return 'https://www.tibia.com/community/?subtopic=characters&name='+encodeURIComponent(name);}
function charCard(ch){const p=ch.profile||{},role=ch.role,isSub=role!=='main',st=ch.verification_status,status=pretty[st]||st;const success=st==='verified';
  const detail = ch.checked_at ? `<div class="meta-line"><span>World <b>${safe(p.world||'—')}</b></span><span>BattlEye <b>${safe((p.battleye||'unknown').toUpperCase())}</b></span><span>Level <b>${safe(p.level??'—')}</b></span><span>Premium <b>${safe(p.account_status||'—')}</b></span>${p.guild?`<span>Guild <b>${safe(p.guild)}</b></span>`:''}</div>` : '';
  return `<article class="challenge-card ${success?'verified':''}" data-role="${role}"><div class="challenge-head"><div class="challenge-identity"><div class="role-icon ${role}">${icons[role]}</div><div><div class="challenge-role">${labels[role]}</div><div class="challenge-name">${safe(ch.name)}</div><div class="challenge-subtitle">${role==='main'?'Required world: Premia':`Required protection: ${role} BattlEye`}</div></div></div><span class="status-chip ${safe(st)}">${safe(status)}</span></div>
  <div class="challenge-rule"></div><div class="code-row"><div class="code-box"><span>YOUR COMMENT VERIFICATION CODE</span><code>${safe(ch.code)}</code></div><button type="button" class="copy-code" data-copy="${safe(ch.code)}">Copy code</button></div><div class="challenge-foot"><span>Valid until ${safe(new Date(ch.code_expires_at).toLocaleDateString())}</span><a href="${publicUrl(ch.name)}" target="_blank" rel="noopener noreferrer">Open Tibia.com profile ↗</a></div>${ch.error?`<div class="challenge-message">${safe(ch.error)}</div>`:''}${detail}
  ${isSub && !['approved','rejected'].includes(verifyData?.status)?`<div class="upload-box ${ch.has_screenshot?'is-uploaded':''}"><div><strong>${ch.has_screenshot?'✓ Screenshot securely uploaded':'◫ Upload in-game screenshot'}</strong><p>${ch.has_screenshot?'You can replace it if needed.':'PNG, JPG or WebP · max 6 MB · admin-only access'}</p></div><button type="button" data-upload="${role}">${ch.has_screenshot?'Replace':'Choose image'}</button><input type="file" accept="image/png,image/jpeg,image/webp" data-file="${role}" hidden></div>`:''}</article>`;
}
let verifyData=null;
const token=document.body.dataset.token;
function renderVerify(data){verifyData=data;
  const status = data.status;
  $('#application-status').textContent = {pending:'Verification pending',ready:'Ready for admin review',approved:'Approved ✓',rejected:'Rejected'}[status]||status;
  $('#application-created').textContent='Created '+new Date(data.created_at).toLocaleDateString();
  $('#character-cards').innerHTML=data.characters.map(charCard).join('');
  const ok=data.characters.filter(c=>c.verification_status==='verified').length;
  $('#count-verified').textContent=ok;
  $('#overview-bars').innerHTML=data.characters.map(c=>`<span class="${c.verification_status==='verified'?'active':''}"></span>`).join('');
  $('#main-world').textContent=data.characters[0]?.world_match?'Confirmed Premia':(data.characters[0]?.checked_at?'Not confirmed':'Not checked');
  $('#green-shot').textContent=data.characters.find(c=>c.role==='green')?.has_screenshot?'Uploaded ✓':'Missing';
  $('#yellow-shot').textContent=data.characters.find(c=>c.role==='yellow')?.has_screenshot?'Uploaded ✓':'Missing';
  $('#check-all').disabled=['approved','rejected'].includes(status);
  $('#overview-message').textContent=status==='approved'?'Your registration has been approved by the administrator.':status==='rejected'?'This submission was rejected by the administrator.':data.ready_for_review?'All three codes and both screenshots are verified. Your application is now ready for the administrator.':'Verify all three codes and upload both screenshots to submit your application for final review.';
}
async function refreshVerify(){const data=await api('/api/submissions/'+encodeURIComponent(token));renderVerify(data);}
function verifyPage(){if(!token)return;saveLink(token);
  refreshVerify().catch(ex=>error($('#verify-error'),ex.message));
  $('#character-cards').addEventListener('click',async e=>{
    const copy=e.target.closest('[data-copy]');if(copy){try{await navigator.clipboard.writeText(copy.dataset.copy);copy.textContent='Copied ✓';setTimeout(()=>{if(copy.isConnected)copy.textContent='Copy code';},1900);}catch{prompt('Copy your code:',copy.dataset.copy);}return;}
    const pick=e.target.closest('[data-upload]');if(pick){pick.closest('.upload-box').querySelector('input[type=file]').click();}
  });
  $('#character-cards').addEventListener('change',async e=>{if(!e.target.matches('[data-file]'))return;
    const role=e.target.dataset.file,file=e.target.files?.[0];if(!file)return;
    if(file.size>6*1024*1024){error($('#verify-error'),'The screenshot must be under 6 MB.');return;}
    const form=new FormData();form.append('file',file);error($('#verify-error'),'');const button=e.target.closest('.upload-box').querySelector('button');button.disabled=true;button.textContent='Uploading…';
    try{const data=await api('/api/submissions/'+encodeURIComponent(token)+'/screenshot/'+role,{method:'POST',body:form});renderVerify(data);}
    catch(ex){error($('#verify-error'),ex.message);button.disabled=false;button.textContent='Try again';}
  });
  $('#check-all').addEventListener('click',async()=>{const btn=$('#check-all');error($('#verify-error'),'');setBusy(btn,true,'Checking Tibia profiles…');try{const data=await api('/api/submissions/'+encodeURIComponent(token)+'/check',{method:'POST'});renderVerify(data);}catch(ex){error($('#verify-error'),ex.message);}finally{setBusy(btn,false);}});
  $('#copy-link').addEventListener('click',async()=>{const btn=$('#copy-link');try{await navigator.clipboard.writeText(location.href);btn.textContent='Verification link copied ✓';setTimeout(()=>btn.textContent='Copy my verification link',2300);}catch{prompt('Save this link:',location.href);}});
}
if(document.body.dataset.page==='home')home();
if(document.body.dataset.page==='verify')verifyPage();
if(document.body.dataset.page==='admin-login')login();
