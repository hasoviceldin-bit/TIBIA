'use strict';
const $=s=>document.querySelector(s);
const safe=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const csrf=$('meta[name=csrf-token]').content;
const pretty={pending:'Pending',ready:'Ready for review',approved:'Approved',rejected:'Rejected',verified:'Verified',not_found:'Not found',mismatch:'Mismatch',unavailable:'Unavailable',expired:'Expired'};
async function api(path,opt={}){const r=await fetch(path,{credentials:'same-origin',...opt});if(r.status===401){location.href='/admin/login';throw Error('Session expired');}const d=await r.json().catch(()=>({}));if(!r.ok)throw Error(d.detail||`HTTP ${r.status}`);return d;}
let all=[];
function date(v){try{return new Date(v).toLocaleDateString(undefined,{day:'2-digit',month:'short',year:'numeric'});}catch{return '—';}}
function char(c){return `<div class="cell-char"><span class="cell-dot ${c.role==='yellow'?'yellow':''}"></span><span>${safe(c.name)}</span></div><span class="${c.verification_status==='verified'?'mini-verified':'mini-pending'}">${c.verification_status==='verified'?'✓ Verified':'○ '+safe(pretty[c.verification_status]||c.verification_status)}</span>`;}
function row(s){const chars=Object.fromEntries(s.characters.map(c=>[c.role,c]));const good=s.characters.filter(c=>c.verification_status==='verified').length;
return `<tr><td><div class="cell-identity"><div class="mini-avatar">${safe(s.main_name.slice(0,1).toUpperCase())}</div><div><strong>${safe(s.main_name)}</strong><small>Premia · #${s.id}</small></div></div></td><td>${char(chars.green)}</td><td>${char(chars.yellow)}</td><td><span class="progress-text">${good}/3 codes</span><div class="progress-mini">${s.characters.map(c=>`<span class="${c.verification_status==='verified'?'done':''}"></span>`).join('')}</div></td><td><span class="status-chip ${safe(s.status)}">${safe(pretty[s.status]||s.status)}</span></td><td>${safe(date(s.created_at))}</td><td><button class="table-action" data-open="${s.id}">Review →</button></td></tr>`;}
async function load(){try{const q=$('#admin-search').value.trim(),st=$('#status-filter').value;const result=await api('/api/admin/submissions?search='+encodeURIComponent(q)+'&status='+encodeURIComponent(st));all=result.items;const t=result.totals;$('#stat-total').textContent=result.total;$('#stat-pending').textContent=t.pending||0;$('#stat-ready').textContent=t.ready||0;$('#stat-approved').textContent=t.approved||0;$('#table-count').textContent=all.length+' records';$('#admin-rows').innerHTML=all.length?all.map(row).join(''):'<tr><td colspan="7" class="empty-table">No applications found. New registrations will appear here.</td></tr>';}catch(e){$('#admin-rows').innerHTML='<tr><td colspan="7" class="empty-table">'+safe(e.message)+'</td></tr>';}}
function field(title,value){return `<div><label>${safe(title)}</label><strong>${safe(value??'Not public')}</strong></div>`;}
function detailChar(c){const p=c.profile||{};const role=c.role;
return `<section class="detail-character"><div class="detail-char-top"><div><small>${safe(role.toUpperCase())} CHARACTER</small><h3>${safe(c.name)}</h3></div><span class="status-chip ${safe(c.verification_status)}">${safe(pretty[c.verification_status]||c.verification_status)}</span></div>
<div class="detail-data">${field('Game world',p.world)}${field('BattlEye category',p.battleye)}${field('Level',p.level)}${field('Vocation',p.vocation)}${field('Account status',p.account_status)}${field('Last login',p.last_login)}${field('Guild',p.guild)}${field('Guild rank',p.guild_rank)}${field('Code check',c.checked_at?date(c.checked_at):'Not checked')} ${field('Screenshot',role==='main'?'Not required':c.has_screenshot?'Uploaded':'Missing')}</div>
<div class="challenge-message">${safe(c.error||'Waiting for verification check.')}</div><div class="meta-line"><span>Verification code: <b>${safe(c.code)}</b></span></div>
${c.screenshot_url?`<a href="${safe(c.screenshot_url)}" target="_blank" rel="noopener noreferrer"><img class="detail-screenshot" src="${safe(c.screenshot_url)}" alt="Screenshot submitted for ${safe(c.name)}"><span class="shot-link">Open full screenshot ↗</span></a>`:''}</section>`;
}
function accountInfo(s){const names={main:'Premia main',green:'Green character',yellow:'Yellow character'};
const pairs=s.account_links||[];
return `<div class="account-context"><h4>Public account cross-check</h4>${pairs.map(p=>`<p>${names[p.a]} ↔ ${names[p.b]}: <b style="color:${p.publicly_linked?'#91ddb1':'#9cadbf'}">${p.publicly_linked?'Shown together in public account list':'Not publicly confirmed'}</b></p>`).join('')}<p>Public account lists can be hidden or incomplete. Independent comment codes are required for every character.</p></div>`;}
function reviewSection(s){return `<div class="review-panel"><h4>Administrator decision</h4><p style="font-size:11px;color:#a0adba">Approve only when all three profile comment codes, their required worlds and both screenshots pass.</p><textarea id="review-note" placeholder="Optional internal note (reason, comments, review findings)…">${safe(s.admin_note||'')}</textarea><div class="review-actions"><button class="approve-btn" data-decision="approved" ${s.ready_for_review?'':'disabled title="Evidence incomplete"'}>✓ Approve</button><button class="reject-btn" data-decision="rejected">✕ Reject</button><button class="secondary-button" data-decision="pending">Reset to pending</button><button class="reject-btn" data-delete="1" title="Delete this submission and its private screenshots">Delete permanently</button></div><div id="review-error" class="review-error" aria-live="polite"></div></div>`;}
let openId=null;
async function openDetail(id){openId=id;const s=await api('/api/admin/submissions/'+id);$('#modal-title').textContent=s.main_name;$('#detail-content').innerHTML=`<div class="modal-meta"><span>Application #${s.id} · Submitted ${safe(date(s.created_at))}</span><span class="status-chip ${safe(s.status)}">${safe(pretty[s.status]||s.status)}</span></div>${s.characters.map(detailChar).join('')}${accountInfo(s)}${reviewSection(s)}`;$('#detail-overlay').hidden=false;document.body.style.overflow='hidden';}
function close(){openId=null;$('#detail-overlay').hidden=true;document.body.style.overflow='';}
$('#admin-rows').addEventListener('click',e=>{const el=e.target.closest('[data-open]');if(el)openDetail(Number(el.dataset.open)).catch(x=>alert(x.message));});
$('#close-detail').addEventListener('click',close);
$('#detail-overlay').addEventListener('click',e=>{if(e.target.id==='detail-overlay')close();});
document.addEventListener('keydown',e=>{if(e.key==='Escape')close();});
$('#detail-content').addEventListener('click',async e=>{const btn=e.target.closest('[data-decision]');if(!btn||!openId)return;
const decision=btn.dataset.decision,note=$('#review-note').value;
btn.disabled=true;$('#review-error').textContent='';
try{await api('/api/admin/submissions/'+openId+'/review',{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':csrf},body:JSON.stringify({decision,note})});await load();await openDetail(openId);}catch(err){$('#review-error').textContent=err.message;btn.disabled=false;}});
$('#detail-content').addEventListener('click',async e=>{
  const btn=e.target.closest('[data-delete]'); if(!btn||!openId)return;
  if(!confirm('Permanently delete this registration and both screenshots? This cannot be undone.'))return;
  btn.disabled=true;$('#review-error').textContent='';
  try {await api('/api/admin/submissions/'+openId,{method:'DELETE',headers:{'X-CSRF-Token':csrf}});close();await load();}
  catch(err){$('#review-error').textContent=err.message;btn.disabled=false;}
});
$('#export-csv').addEventListener('click',()=>{window.location.href='/api/admin/export.csv';});
$('#logout').addEventListener('click',async()=>{await api('/api/admin/logout',{method:'POST',headers:{'X-CSRF-Token':csrf}});location.href='/admin/login';});
let debounce;$('#admin-search').addEventListener('input',()=>{clearTimeout(debounce);debounce=setTimeout(load,240);});$('#status-filter').addEventListener('change',load);$('#refresh').addEventListener('click',load);
load();
