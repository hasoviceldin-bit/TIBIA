@echo off
setlocal
cd /d "%~dp0"
echo.
echo =====================================
echo        TIBIA VERIFY - LOCAL SERVER
 echo =====================================
if not exist ".venv\Scripts\python.exe" (
  echo Creating Python virtual environment...
  py -3 -m venv .venv
  if errorlevel 1 (echo Could not create a virtual environment. Install Python 3.11 or newer.& pause & exit /b 1)
)
call ".venv\Scripts\activate.bat"
python -m pip install -r requirements.txt
if errorlevel 1 (echo Dependency installation failed.& pause & exit /b 1)
echo.
echo Registration page: http://127.0.0.1:8000
echo Admin dashboard:   http://127.0.0.1:8000/admin
echo DEMO ONLY - change password before publishing online.
echo Press CTRL+C to stop.
echo.
start "" "http://127.0.0.1:8000"
python -m uvicorn server:app --host 127.0.0.1 --port 8000
pause
