#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
[ -d .venv ] || python3 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
printf '\nTibia Verify: http://127.0.0.1:8000\nAdmin: http://127.0.0.1:8000/admin\n'
exec python -m uvicorn server:app --host 127.0.0.1 --port 8000
