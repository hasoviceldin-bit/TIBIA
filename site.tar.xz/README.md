# Tibia Verify — Character Registration and Admin Review

A full-stack, runnable Tibia character-verification website. Built with **FastAPI**, **SQLite**, **TibiaData v5**, and a responsive front end. It does not ask players for Tibia credentials.

## Features

- Registration form: Premia **main**, **green BattlEye** character, **yellow BattlEye** character
- Three independent random ownership challenges, one per character
- Checks each challenge against that character's public **Comment** field, via TibiaData's public-data endpoint
- Checks the main is on **Premia**, the green character is on a world protected since launch, and the yellow character is on a world protected later
- Uploads a screenshot for each of the green/yellow characters; private administrator-only storage (converted to safe WebP and EXIF-stripped)
- Retrieves public world, level, vocation, last login, guild, and **Premium/Free account status** (remaining premium days are not public)
- Checks *publicly listed* account-character associations (not mandatory; they can be hidden or incomplete)
- Admin login, submission dashboard grouped by main, screenshot review, approval/rejection, comments, CSV export
- SQLite persistence, CSRF-protected admin state changes, private screenshot endpoints

## Run locally

Python 3.11+ recommended.

```bash
cd tibia-character-verification
python -m venv .venv
# Linux/macOS: source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn server:app --reload --host 127.0.0.1 --port 8000
```

On Windows, you can also double-click `START_WINDOWS.bat` to install dependencies and start the server.

Open <http://127.0.0.1:8000> and visit <http://127.0.0.1:8000/admin> for the dashboard.

**Requested initial admin login (LOCAL/DEMO ONLY):** username `admin`, password `hej123`.

**Before a public deployment, you MUST set a strong password**. `hej123` is trivially guessable and is provided only because it was explicitly requested. Set environment variables before starting:

```bash
export ADMIN_USERNAME="admin"
export ADMIN_PASSWORD="REPLACE_WITH_A_UNIQUE_LONG_RANDOM_PASSWORD"
export SESSION_SECRET="REPLACE_WITH_A_LONG_RANDOM_SECRET"
export COOKIE_SECURE=1        # only when served via HTTPS
export TIBIA_DATA_DIR=/var/lib/tibia-verify
uvicorn server:app --host 127.0.0.1 --port 8000
```

Under Windows PowerShell use `$env:ADMIN_PASSWORD = "..."` rather than `export`.

For internet exposure, put the app behind HTTPS and a production reverse proxy, add proxy-side request/rate limiting and appropriate backups. Restrict access to `/admin` as appropriate. A locally set weak password must **never** be reused online.

## How player verification works

1. Enter three distinct character names and click **Generate verification codes**.
2. On each character's tibia.com account profile, paste its generated `TCV-XXXX-XXXX` challenge into the public **Comment** field and save changes.
3. Wait for the public data source to refresh (the TibiaData response may be cached).
4. Click **Check all characters on Tibia**. The backend independently fetches each character and world.
5. Upload **two screenshots**, one each for the green and yellow characters.
6. The registration becomes **Ready for review** only after all three codes and world checks pass and both screenshots are uploaded. Admin makes the final decision.

Each challenge is valid for **7 days**. Restart with a new registration if an unused code expires. Registered players should bookmark their private verification page link; the link grants access to their submission.

## Data accuracy and limitations

The verification backend uses **https://api.tibiadata.com/v5/character/{name}** and **https://api.tibiadata.com/v5/worlds**. TibiaData collects publicly available character/world information from **tibia.com**, but it is not CipSoft's official authentication API. Production deployments should monitor this third-party API for changes or outages. The server preserves pending verification when the data source is unavailable rather than falsely reporting a failure.

A code appearing on the public character profile is evidence of control of that profile **at verification time**, not a permanent proof of ownership or of a common Tibia account. Players on different Tibia accounts can separately verify each character. Last-login date, guild, account status and publicly linked alts are supporting signals only. Private Premium time remaining is not publicly verifiable. Uploaded screenshots are evidence for human review, not machine-authenticated ownership proof.

World status is classified using the `battleye_protected` and `battleye_date` properties: `release` = green; a concrete launch-later date = yellow; unknown is not accepted.

## Test

```bash
python -m pytest -q tests
```

The end-to-end tests simulate the external TibiaData response so they run without internet access. **Live third-party API behavior has to be tested on a connected server with real Tibia characters.**

## Files

- `server.py` — API, DB, verification logic, image processing, admin authentication and CSV export
- `templates/` — registration, challenge, login, dashboard
- `static/` — responsive design, client interactions
- `tests/` — end-to-end functional tests
- `data/` — generated at runtime; holds secrets, SQLite DB and screenshots (don't commit this to Git)

## Data retention

The prototype retains submitted public character metadata and screenshots until an administrator deletes its data directory. For a public rollout, add a privacy notice, a retention/deletion policy, explicit consent, and an administrator delete-data feature. Avoid including private account details in screenshots.

Independent fan project, not affiliated with CipSoft.


## Render deployment (production)
`render.yaml` describes a **paid Starter** Python web service in Frankfurt with a **1 GB persistent disk**. This is essential because the app stores SQLite records and uploaded screenshots on its filesystem; Render free web services have ephemeral disks. Render will generate the session secret; the administrator must provide a **new strong password of 16+ characters**, not `hej123`. `PRODUCTION=1` refuses to boot with insecure settings. Review the cost in Render before approving deployment.

Only one application instance is supported with the SQLite disk. `GET /health` can be used as the hosting health check. The admin dashboard supports permanent removal of submissions and screenshots.

TibiaData v5 responses use the same character/world fields as v4. The external live API must be smoke-tested after the site is deployed (tests use mocked upstream responses).
